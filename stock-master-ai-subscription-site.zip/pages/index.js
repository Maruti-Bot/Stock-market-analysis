import { useEffect, useState } from 'react'

export default function Home() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [screenshot, setScreenshot] = useState(null)

  // Load Razorpay script
  useEffect(() => {
    const existing = document.querySelector('script[src="https://checkout.razorpay.com/v1/checkout.js"]')
    if (!existing) {
      const script = document.createElement('script')
      script.src = 'https://checkout.razorpay.com/v1/checkout.js'
      script.async = true
      document.body.appendChild(script)
    }
  }, [])

  const payWithRazorpay = async () => {
    try {
      setLoading(true); setError(null)
      const res = await fetch('/api/create-order', { method: 'POST' })
      const order = await res.json()

      const options = {
        key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID || 'rzp_test_xxx',
        amount: order.amount,
        currency: order.currency,
        name: 'Stock Master AI',
        description: 'Premium Subscription',
        order_id: order.id,
        handler: async function (response) {
          // verify signature on server
          const verifyRes = await fetch('/api/verify-payment', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(response)
          })
          const data = await verifyRes.json()
          if (verifyRes.ok) {
            setResult({ ok: true, msg: 'Payment verified! Access unlocked.' })
          } else {
            setError(data.error || 'Verification failed, contact support.')
          }
        },
        prefill: {
          name: 'Subscriber',
          email: 'user@example.com',
          contact: '862557919'
        },
        theme: { color: '#3399cc' }
      }
      const rzp = new window.Razorpay(options)
      rzp.open()
    } catch (e) {
      setError(e?.message || 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }

  const onFileChange = (e) => setScreenshot(e.target.files?.[0] || null)

  const uploadScreenshot = async () => {
    if (!screenshot) { alert('Upload screenshot first'); return; }
    const fd = new FormData()
    fd.append('file', screenshot)
    const res = await fetch('/api/manual-upload', { method: 'POST', body: fd })
    const data = await res.json()
    if (res.ok) setResult({ ok: true, msg: 'Screenshot received. We will verify and enable access shortly.' })
    else setError(data.error || 'Upload failed')
  }

  return (
    <div className="container">
      <h1>Subscribe to <b>Stock Master AI</b></h1>
      <p>Unlock premium market analysis for just <b>₹100</b>.</p>

      <div className="card">
        <button className="btn" onClick={payWithRazorpay} disabled={loading}>
          {loading ? 'Starting Checkout...' : 'Pay ₹100 with Razorpay'}
        </button>

        <div className="hr">OR</div>

        <div>
          <img src="/phonepe-qr.jpeg" alt="PhonePe QR" className="qr" />
          <p className="center note">Scan & pay using PhonePe / any UPI app.</p>
          <div className="mt-3">
            <input type="file" onChange={onFileChange} accept="image/*" />
            <button className="btn secondary mt-2" onClick={uploadScreenshot}>Submit Screenshot</button>
          </div>
          <p className="note mt-2">If you pay via QR, we will activate access after verifying the payment.</p>
        </div>

        <div className="mt-4">
          {result?.ok && <div className="success">{result.msg}</div>}
          {error && <div className="error">{error}</div>}
        </div>
      </div>
    </div>
  )
}
