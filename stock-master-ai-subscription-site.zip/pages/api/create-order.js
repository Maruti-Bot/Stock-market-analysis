import Razorpay from 'razorpay'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' })

  try {
    const rzp = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET
    })
    const order = await rzp.orders.create({
      amount: 10000, // ₹100 in paise
      currency: 'INR',
      receipt: 'smai_' + Date.now(),
      notes: { plan: 'monthly_100' }
    })
    res.status(200).json(order)
  } catch (e) {
    res.status(500).json({ error: e.message })
  }
}
