import crypto from 'crypto'
import cookie from 'cookie'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' })

  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body || {}
  if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
    return res.status(400).json({ error: 'Missing payment details' })
  }

  const keySecret = process.env.RAZORPAY_KEY_SECRET
  const generated_signature = crypto
    .createHmac('sha256', keySecret)
    .update(razorpay_order_id + '|' + razorpay_payment_id)
    .digest('hex')

  if (generated_signature !== razorpay_signature) {
    return res.status(400).json({ error: 'Invalid signature' })
  }

  // Set subscription cookie
  const cookieName = process.env.SUB_COOKIE_NAME || 'stock_master_sub'
  const ttlDays = parseInt(process.env.SUB_COOKIE_TTL_DAYS || '30', 10)
  const maxAge = ttlDays * 24 * 60 * 60

  res.setHeader('Set-Cookie', cookie.serialize(cookieName, 'true', {
    httpOnly: true,
    secure: true,
    sameSite: 'lax',
    path: '/',
    maxAge
  }))

  return res.status(200).json({ ok: true })
}
