import crypto from 'crypto'
import cookie from 'cookie'

export const config = {
  api: { bodyParser: { sizeLimit: '1mb' } }
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' })

  const webhookSecret = process.env.WEBHOOK_SECRET
  const body = JSON.stringify(req.body)
  const signature = req.headers['x-razorpay-signature']

  const expected = crypto.createHmac('sha256', webhookSecret).update(body).digest('hex')
  if (signature !== expected) {
    return res.status(400).json({ error: 'Invalid webhook signature' })
  }

  // Example: you could look at event type and payment status here
  // const event = req.body.event

  return res.status(200).json({ ok: true })
}
