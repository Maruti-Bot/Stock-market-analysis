import formidable from 'formidable'
import fs from 'fs'
import path from 'path'

export const config = {
  api: { bodyParser: false }
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' })

  const form = formidable({ multiples: false })
  form.parse(req, async (err, fields, files) => {
    if (err) return res.status(500).json({ error: 'Parsing error' })
    const file = files.file
    if (!file) return res.status(400).json({ error: 'No file uploaded' })

    const uploadDir = path.join(process.cwd(), 'uploads')
    if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir)

    const dest = path.join(uploadDir, file.originalFilename || 'screenshot.jpg')
    await fs.promises.copyFile(file.filepath, dest)

    return res.status(200).json({ ok: true, path: '/uploads/' + path.basename(dest) })
  })
}
