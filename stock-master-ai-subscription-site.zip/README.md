# Stock Master AI – Subscription Website

Features:
- Razorpay automated checkout for ₹100 subscription
- Backup PhonePe QR (scan & pay)
- Manual screenshot upload (stored in `/uploads` when self-hosted)
- Signature verification on server and auth cookie set for access control

## Quick Start

```bash
npm install
cp .env.local.example .env.local
# Fill RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET, WEBHOOK_SECRET
npm run dev
```

Visit http://localhost:3000

## Deploy
- **Vercel/Netlify**: Works out of the box for API routes.
- Configure environment variables in the dashboard.
- Set Razorpay Webhook URL to: `https://YOUR_DOMAIN/api/webhook` with your `WEBHOOK_SECRET`.

## Access Control
After successful verification, we set an HttpOnly cookie (`SUB_COOKIE_NAME`).
Use this cookie to gate your premium pages (e.g., check it in `getServerSideProps`).

## Notes
- For manual uploads on Vercel, use an external storage (S3/Supabase). This starter saves to `/uploads` for self-hosting/local use.
